// +build !linux

package main

func earlyInitHook() {
}
