// +build !amd64 amd64,windows

package machine

func init() {}
