Manage the destination(s) for Podman service(s)
=================

:doc:`add <markdown/podman-system-connection-add.1>` Record destination for the Podman service

:doc:`default <markdown/podman-system-connection-default.1>` Set named destination as default for the Podman service

:doc:`list <markdown/podman-system-connection-list.1>` List the destination for the Podman service(s)

:doc:`remove <markdown/podman-system-connection-remove.1>` Delete named destination

:doc:`rename <markdown/podman-system-connection-rename.1>` Rename the destination for Podman service
