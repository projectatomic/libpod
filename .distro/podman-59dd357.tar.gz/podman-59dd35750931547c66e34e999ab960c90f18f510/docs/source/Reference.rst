.. include:: includes.rst

Reference
=========

To see full screen version please visit: `API documentation <https://docs.podman.io/en/latest/_static/api.html>`_

.. raw:: html

    <iframe src="_static/api.html" allowfullscreen="true" height="600px" width="120%"></iframe>
