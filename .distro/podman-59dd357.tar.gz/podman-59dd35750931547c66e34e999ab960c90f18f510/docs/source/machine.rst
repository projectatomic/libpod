Machine
======


:doc:`init <markdown/podman-machine-init.1>` Initialize a new virtual machine
:doc:`list <markdown/podman-machine-list.1>` List virtual machines
:doc:`rm <markdown/podman-machine-rm.1>` Remove a virtual machine
:doc:`ssh <markdown/podman-machine-ssh.1>` SSH into a virtual machine
:doc:`start <markdown/podman-machine-start.1>` Start a virtual machine
:doc:`stop <markdown/podman-machine-stop.1>` Stop a virtual machine
