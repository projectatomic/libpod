This dockerfile exists so that the container image can be "mirrored"
onto quay.io automatically, so automated testing can be more resilient.

https://quay.io/repository/libpod/fedora-minimal?tab=builds
